"""
ML-Assisted Intelligent Compiler for Automated Syntax Error Detection and Recovery
Educational prototype: tokenizer, recursive-descent parser, error classification,
suggestion ranking, and panic-mode recovery. The optional ML model is a small
TF-IDF + LogisticRegression classifier trained on included synthetic examples.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, asdict
from typing import List, Optional

TOKEN_RE = re.compile(
    r"(?P<COMMENT>//[^\n]*)|(?P<NUMBER>\d+(?:\.\d+)?)|(?P<ID>[A-Za-z_]\w*)|"
    r"(?P<OP>==|!=|<=|>=|[=+\-*/<>])|(?P<LPAREN>\()|(?P<RPAREN>\))|"
    r"(?P<LBRACE>\{)|(?P<RBRACE>\})|(?P<SEMI>;)|(?P<COMMA>,)|"
    r"(?P<SKIP>\s+)|(?P<MISMATCH>.)"
)
KEYWORDS = {"int", "float", "return", "print"}

@dataclass
class Token:
    kind: str
    value: str
    line: int
    column: int

@dataclass
class Diagnostic:
    line: int
    column: int
    category: str
    message: str
    suggestion: str
    recovered_as: str = ""

class Lexer:
    def tokenize(self, source: str) -> tuple[list[Token], list[Diagnostic]]:
        tokens, errors = [], []
        line = column = 1
        for m in TOKEN_RE.finditer(source):
            value, kind = m.group(), m.lastgroup
            if kind in ("SKIP", "COMMENT"):
                newlines = value.count("\n")
                if newlines:
                    line += newlines
                    column = len(value.rsplit("\n", 1)[-1]) + 1
                else:
                    column += len(value)
                continue
            if kind == "MISMATCH":
                errors.append(Diagnostic(line, column, "Lexical error",
                    f"Unexpected character {value!r}.",
                    "Remove the character or replace it with a valid token."))
                column += len(value)
                continue
            if kind == "ID" and value in KEYWORDS:
                kind = "KEYWORD"
            tokens.append(Token(kind, value, line, column))
            column += len(value)
        tokens.append(Token("EOF", "", line, column))
        return tokens, errors

class Parser:
    """Recursive-descent parser for statements, blocks, and C-style functions."""
    def __init__(self, tokens: list[Token]):
        self.tokens, self.i, self.errors = tokens, 0, []

    def cur(self): return self.tokens[min(self.i, len(self.tokens)-1)]

    def advance(self):
        t = self.cur()
        if t.kind != "EOF": self.i += 1
        return t

    def accept(self, value=None, kind=None):
        t = self.cur()
        if (value is None or t.value == value) and (kind is None or t.kind == kind):
            self.advance(); return True
        return False

    def report(self, category, message, suggestion, recovered=""):
        t = self.cur()
        self.errors.append(Diagnostic(t.line, t.column, category, message, suggestion, recovered))

    def expect(self, value, category, suggestion):
        if self.accept(value=value): return True
        self.report(category, f"Expected {value!r}, found {self.cur().value or 'end of input'!r}.",
                    suggestion, f"insert {value!r}")
        return False

    def parse(self):
        statements = []
        while self.cur().kind != "EOF":
            before = self.i
            if self.cur().kind == "RBRACE":
                self.report("Unmatched closing brace", "Found '}' without a matching '{'.",
                            "Remove the extra '}' or add its matching opening brace.")
                self.advance()
                continue
            statements.append(self.statement())
            if self.i == before: self.advance()  # guarantee forward progress
        return {"type": "Program", "statements": statements}, self.errors

    def statement(self):
        t = self.cur()
        if t.kind == "KEYWORD" and t.value in ("int", "float"):
            return self.typed_statement()
        if t.kind == "KEYWORD" and t.value == "print":
            self.advance()
            self.expect("(", "Missing opening parenthesis", "Add '(' after print.")
            expr = self.expression()
            self.expect(")", "Missing closing parenthesis", "Add ')' after the print expression.")
            self.expect(";", "Missing semicolon", "Add ';' at the end of the statement.")
            return {"type":"Print","expression":expr}
        if t.kind == "KEYWORD" and t.value == "return":
            self.advance()
            expr = None if self.cur().value == ";" else self.expression()
            self.expect(";", "Missing semicolon", "Add ';' after the return statement.")
            return {"type":"Return","expression":expr}
        if t.kind == "LBRACE":
            return self.block()
        if t.kind == "ID":
            name = self.advance().value
            if not self.accept("="):
                self.report("Missing assignment operator",
                    f"Expected '=' after variable {name!r}.",
                    f"Write {name} = expression;", "insert '='")
                self.recover_statement()
                return {"type":"InvalidStatement","name":name}
            expr = self.expression()
            self.expect(";", "Missing semicolon", "Add ';' at the end of the statement.")
            return {"type":"Assignment","name":name,"expression":expr}
        self.report("Unexpected token", f"Cannot start a statement with {t.value!r}.",
                    "Start with a declaration, identifier, print, return, or '{'.")
        self.recover_statement()
        return {"type":"InvalidStatement"}

    def typed_statement(self):
        data_type = self.advance().value
        if self.cur().kind != "ID":
            self.report("Missing identifier", "Declaration or function definition needs a name.",
                        "Add an identifier after the type name.")
            self.recover_statement()
            return {"type":"InvalidStatement"}

        name = self.advance().value
        if self.cur().kind == "LPAREN":
            return self.function_definition(data_type, name)
        if self.cur().kind == "LBRACE":
            self.report("Missing opening parenthesis",
                        f"Expected '(' after function name {name!r}.",
                        "Add '()' after the function name.")
            self.report("Missing closing parenthesis",
                        f"Expected ')' after the parameter list for {name!r}.",
                        "Add ')' before the function body.")
            return self.function_definition(data_type, name, has_parentheses=False)

        node = {"type":"Declaration","data_type":data_type,"name":name}
        if self.accept("="):
            node["initializer"] = self.expression()
        self.expect(";", "Missing semicolon", "Add ';' at the end of the declaration.")
        return node

    def function_definition(self, return_type, name, has_parentheses=True):
        parameters = []
        if has_parentheses:
            self.advance()  # opening parenthesis
            while self.cur().kind not in ("RPAREN", "LBRACE", "EOF"):
                if self.cur().kind == "KEYWORD" and self.cur().value in ("int", "float"):
                    parameter_type = self.advance().value
                    if self.cur().kind == "ID":
                        parameter_name = self.advance().value
                        parameters.append({
                            "type":"Parameter", "data_type":parameter_type, "name":parameter_name
                        })
                    else:
                        self.report("Missing identifier", "Function parameter needs a name.",
                                    "Add a parameter name after its type.")
                    if not self.accept(value=",") and self.cur().kind != "RPAREN":
                        if self.cur().kind not in ("LBRACE", "EOF"):
                            self.report("Unexpected token", "Expected ',' between function parameters.",
                                        "Add a comma between parameter declarations.")
                            self.recover_to("COMMA", "RPAREN", "LBRACE", "EOF")
                            self.accept(value=",")
                    continue
                self.report("Invalid function parameter",
                            f"Expected a parameter type, found {self.cur().value or 'end of input'!r}.",
                            "Use a typed parameter such as 'int value', separated by commas.")
                self.recover_to("COMMA", "RPAREN", "LBRACE", "EOF")
                if self.accept(value=","):
                    continue
                break
            self.expect(")", "Missing closing parenthesis",
                        f"Add ')' after the parameter list for {name!r}.")

        body = self.function_body()
        return {
            "type":"FunctionDefinition",
            "return_type":return_type,
            "name":name,
            "parameters":parameters,
            "body":body,
        }

    def function_body(self):
        if self.cur().kind == "LBRACE":
            return self.block()

        self.report("Missing opening brace",
                    "Expected '{' to begin the function body.",
                    "Add '{' before the function's statements.")
        statements = []
        while self.cur().kind not in ("RBRACE", "EOF"):
            before = self.i
            statements.append(self.statement())
            if self.i == before:
                self.advance()
        if self.accept(kind="RBRACE"):
            return {"type":"Block", "statements":statements}
        return {"type":"Block", "statements":statements}

    def block(self):
        self.advance()  # opening brace
        statements = []
        while self.cur().kind not in ("RBRACE", "EOF"):
            before = self.i
            statements.append(self.statement())
            if self.i == before:
                self.advance()
        if self.cur().kind == "RBRACE":
            self.advance()
        else:
            self.report("Missing closing brace", "Expected '}' to close this block before end of input.",
                        "Add '}' at the end of the block.")
        return {"type":"Block", "statements":statements}

    def expression(self):
        node = self.term_expr()
        while self.cur().value in ("+", "-"):
            op = self.advance().value
            node = {"type":"Binary","operator":op,"left":node,"right":self.term_expr()}
        return node

    def term_expr(self):
        node = self.factor()
        while self.cur().value in ("*", "/"):
            op = self.advance().value
            node = {"type":"Binary","operator":op,"left":node,"right":self.factor()}
        return node

    def factor(self):
        t = self.cur()
        if t.kind in ("NUMBER","ID"):
            self.advance()
            return {"type":"Number" if t.kind=="NUMBER" else "Identifier","value":t.value}
        if self.accept("("):
            expr = self.expression()
            self.expect(")", "Missing closing parenthesis", "Add ')' to close the expression.")
            return expr
        self.report("Missing expression", f"Expected a number, identifier, or '('. Found {t.value or 'end of input'!r}.",
                    "Insert an expression such as 5 or variable_name.")
        if t.kind not in ("EOF", "SEMI", "RPAREN", "RBRACE", "COMMA"):
            self.advance()
        return {"type":"ErrorExpression"}

    def recover_to(self, *kinds):
        while self.cur().kind not in kinds:
            self.advance()

    def recover_statement(self):
        while self.cur().kind not in ("SEMI", "RBRACE", "EOF"):
            self.advance()
        self.accept(value=";")

class ErrorClassifier:
    """Optional ML classifier; safely falls back to rule-based labels offline."""
    def __init__(self):
        self.model = None
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.linear_model import LogisticRegression
            examples = [
                ("Expected ';' after statement", "Missing semicolon"),
                ("Expected ')' found end of input", "Missing closing parenthesis"),
                ("Unexpected character @", "Lexical error"),
                ("Expected '=' after variable", "Missing assignment operator"),
                ("Expected identifier after int", "Missing identifier"),
                ("Expected number or identifier", "Missing expression"),
                ("Cannot start a statement with }", "Unexpected token"),
                ("Expected '(' after print", "Missing opening parenthesis"),
            ]
            x=[a for a,b in examples]; y=[b for a,b in examples]
            self.vectorizer=TfidfVectorizer(ngram_range=(1,2))
            self.model=LogisticRegression(max_iter=500).fit(self.vectorizer.fit_transform(x),y)
        except Exception:
            self.vectorizer = None
    def classify(self, diagnostic: Diagnostic) -> str:
        if self.model is None: return diagnostic.category
        text = diagnostic.message + " " + diagnostic.suggestion
        pred = self.model.predict(self.vectorizer.transform([text]))[0]
        # Parser's rule-based category is authoritative when it is more specific.
        return diagnostic.category if diagnostic.category else pred

def compile_source(source: str):
    lexer = Lexer()
    tokens, lexical_errors = lexer.tokenize(source)
    parser = Parser(tokens)
    ast, syntax_errors = parser.parse()
    diagnostics = lexical_errors + syntax_errors
    classifier = ErrorClassifier()
    for d in diagnostics:
        d.category = classifier.classify(d)
    return {"tokens":[asdict(t) for t in tokens if t.kind!="EOF"],
            "ast":ast, "diagnostics":[asdict(d) for d in diagnostics],
            "success":len(diagnostics)==0,
            "ml_classifier_available":classifier.model is not None}

def print_compilation_result(label: str, source: str):
    result = compile_source(source)
    print(f"\n[{label}]")
    print("-" * 60)
    print("Source Code:  ", source)
    print("Status:       ", "SUCCESS" if result["success"] else "ERRORS DETECTED")
    print("ML Classifier:", "Active (TF-IDF + Logistic Regression)" if result["ml_classifier_available"] else "Offline (Rule-based fallback)")
    print("Tokens:       ", " ".join(t["value"] for t in result["tokens"]))
    
    if result["diagnostics"]:
        print(f"\nDiagnostics ({len(result['diagnostics'])} issue(s) detected):")
        for i, d in enumerate(result["diagnostics"], 1):
            print(f"  Issue #{i} [Line {d['line']}, Col {d['column']}]: {d['category']}")
            print(f"    Message:    {d['message']}")
            print(f"    Suggestion: {d['suggestion']}")
            if d["recovered_as"]:
                print(f"    Recovery:   {d['recovered_as']}")
    else:
        print("\nDiagnostics:  None (Code is syntactically valid)")
        
    print(f"AST Statements: {len(result['ast']['statements'])}")
    print("-" * 60)
    return result

def run_demo_examples():
    examples = [
        ("Valid program", "int total = 10; total = total + 5; print(total);"),
        ("Missing semicolon", "int total = 10 total = total + 5;"),
        ("Missing closing parenthesis", "print(10 + 2;"),
        ("Lexical error", "int value = 5 @ 2;"),
    ]
    for label, source in examples:
        print_compilation_result(label, source)

def main(args: list[str] | None = None):
    import sys, os
    if args is None:
        args = sys.argv[1:]

    print("=" * 66)
    print("ML-Assisted Intelligent Compiler - Syntax Detection & Recovery")
    print("=" * 66)

    # 1. Handle command-line arguments: python compiler.py "int x = 5;" or a file path
    if args:
        if "--demo" in args:
            run_demo_examples()
            return
        arg = " ".join(args)
        if os.path.isfile(arg):
            with open(arg, "r", encoding="utf-8") as f:
                code = f.read()
            print_compilation_result(f"File: {arg}", code)
        else:
            print_compilation_result("User Command-Line Input", arg)
        return

    # 2. If non-interactive piped input is detected
    if not sys.stdin.isatty():
        try:
            content = sys.stdin.read().strip()
            if content:
                print_compilation_result("Piped User Input", content)
                return
        except Exception:
            pass
        run_demo_examples()
        return

    # 3. Interactive Menu
    print("\nSelect an option:")
    print("  [1] Enter your own custom code (User-Defined Input)")
    print("  [2] Run built-in demonstration examples")
    print("  [3] Exit")

    try:
        choice = input("\nEnter choice (1/2/3, default [1]): ").strip()
    except (EOFError, KeyboardInterrupt):
        choice = "2"

    if choice == "2":
        run_demo_examples()
    elif choice == "3":
        print("Exiting.")
        return
    else:
        print("\n" + "=" * 66)
        print("INTERACTIVE MODE: Type or paste your C-like code.")
        print("Supported: declarations (int/float), assignments, print(...), return.")
        print("Commands: type 'demo' to run examples, or 'exit' / 'quit' to stop.")
        print("=" * 66)
        while True:
            try:
                code = input("\nEnter code > ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nExiting.")
                break
            if not code:
                continue
            if code.lower() in ("exit", "quit", "q"):
                print("Exiting.")
                break
            if code.lower() == "demo":
                run_demo_examples()
                continue
            print_compilation_result("User Defined Input", code)

if __name__ == "__main__":
    main()
