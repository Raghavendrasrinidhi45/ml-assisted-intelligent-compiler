import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from compiler import compile_source

class CompilerTests(unittest.TestCase):
    def test_valid_program(self):
        r = compile_source("int x = 10; x = x + 2; print(x);")
        self.assertTrue(r["success"])
        self.assertEqual(len(r["ast"]["statements"]), 3)
    def test_missing_semicolon(self):
        r = compile_source("int x = 10")
        self.assertFalse(r["success"])
        self.assertTrue(any("semicolon" in d["category"].lower() for d in r["diagnostics"]))
    def test_lexical_error(self):
        r = compile_source("int x = @;")
        self.assertTrue(any(d["category"] == "Lexical error" for d in r["diagnostics"]))
    def test_recovery(self):
        r = compile_source("x 10; print(3);")
        self.assertEqual(len(r["ast"]["statements"]), 2)

    def test_c_style_function_with_block(self):
        r = compile_source("int main() { int x = 10; return 0; }")
        self.assertTrue(r["success"], r["diagnostics"])
        function = r["ast"]["statements"][0]
        self.assertEqual(function["type"], "FunctionDefinition")
        self.assertEqual(function["name"], "main")
        self.assertEqual(function["body"]["type"], "Block")
        self.assertEqual(
            [statement["type"] for statement in function["body"]["statements"]],
            ["Declaration", "Return"],
        )

    def test_function_parameters_and_arithmetic_precedence(self):
        r = compile_source(
            "int add(int left, int right) { int result = left + right * 2; return result; }"
        )
        self.assertTrue(r["success"], r["diagnostics"])
        function = r["ast"]["statements"][0]
        self.assertEqual([parameter["name"] for parameter in function["parameters"]],
                         ["left", "right"])
        expression = function["body"]["statements"][0]["initializer"]
        self.assertEqual(expression["operator"], "+")
        self.assertEqual(expression["right"]["operator"], "*")

    def test_missing_function_opening_brace_has_location_and_suggestion(self):
        r = compile_source("int main()\n return 0;\n}")
        diagnostic = next(d for d in r["diagnostics"] if d["category"] == "Missing opening brace")
        self.assertEqual((diagnostic["line"], diagnostic["column"]), (2, 2))
        self.assertIn("Add '{'", diagnostic["suggestion"])

    def test_missing_function_closing_brace(self):
        r = compile_source("int main() {\n return 0;\n")
        diagnostic = next(d for d in r["diagnostics"] if d["category"] == "Missing closing brace")
        self.assertEqual((diagnostic["line"], diagnostic["column"]), (3, 1))
        self.assertIn("Add '}'", diagnostic["suggestion"])

    def test_unmatched_closing_brace(self):
        r = compile_source("int main() { return 0; }}")
        diagnostic = next(d for d in r["diagnostics"]
                          if d["category"] == "Unmatched closing brace")
        self.assertEqual((diagnostic["line"], diagnostic["column"]), (1, 25))

    def test_missing_function_parenthesis_and_semicolon(self):
        r = compile_source("int main( { return 0 }")
        categories = [d["category"] for d in r["diagnostics"]]
        self.assertIn("Missing closing parenthesis", categories)
        self.assertIn("Missing semicolon", categories)

        r = compile_source("int main { return 0; }")
        categories = [d["category"] for d in r["diagnostics"]]
        self.assertIn("Missing opening parenthesis", categories)
        self.assertIn("Missing closing parenthesis", categories)

if __name__ == "__main__": unittest.main()
