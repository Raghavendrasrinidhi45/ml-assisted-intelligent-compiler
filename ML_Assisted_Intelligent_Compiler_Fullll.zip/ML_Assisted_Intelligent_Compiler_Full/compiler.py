"""
Root wrapper for the ML-Assisted Intelligent Compiler prototype.
Allows running `python compiler.py` directly from the workspace root.
"""
import sys
from pathlib import Path

src_path = Path(__file__).resolve().parent / "ml_assisted_compiler_project" / "src"
sys.path.insert(0, str(src_path))

from compiler import main, compile_source

if __name__ == "__main__":
    main()
